a = "hello, my name is Leon"
# print(a[-6:])
img = "sdsd/data/image/portrait_3432.png"
# print(a.split())
print(img.split("/")[-1].split(".")[0])